﻿using UnityEngine;
using System.Collections;

public class ExampleNinja : MonoBehaviour {
	private Animator myAnimator;

	private bool isThrow = false;
	private float delayTime = 0.3f;

	public GameObject prefabKunai;

	// Use this for initialization
	void Start () {
		myAnimator = GetComponent<Animator>();
	}
	// Update is called once per frame
	void Update () {
		delayTime -= Time.deltaTime;
		if(delayTime <= 0)
		{
			ThrowKnife();
			delayTime = 0.3f;
			isThrow = false;
		}

	}

	void ThrowKnife()
	{
		if(Input.GetKey(KeyCode.Space))
		{
			isThrow = true;
			myAnimator.SetTrigger("Throw");
			Transform shotBullet = Instantiate(prefabKunai,transform.position, transform.rotation) as Transform;
		}
		Debug.Log(" isThrow: " + isThrow);
	}
		

}
