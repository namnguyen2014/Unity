﻿using UnityEngine;
using System.Collections;

public class PlayerMovement : MonoBehaviour {

	Rigidbody2D rb2D;
	Animator animator;

	float speed = 5f;
	bool isChangeDirection = true;
	bool isOnGround = false;

	// Use this for initialization
	void Start () {
		rb2D = GetComponent<Rigidbody2D>();
		animator = GetComponent<Animator>();
	}

	void FixedUpdate()
	{
		float speedH = Input.GetAxis("Horizontal");
		float HeightV = Input.GetAxis("Vertical");
		Movement(speedH,HeightV);
		Animating(speedH,HeightV);
		ChangeDirectionAnimation(speedH);
	}
	// Xu ly: Di chuyen cua Player
	void Movement(float h, float v)
	{	
		if(h != 0 || v != 0 || isOnGround == false){
			Vector2 movement = new Vector2(h * speed, v * speed);
			rb2D.velocity = movement;
			isOnGround = true;
		}
	}
	// Tao animation cho Run va Jump
	void Animating(float h, float v)
	{
		animator.SetFloat("Speed",Mathf.Abs(h));

		animator.SetFloat("Height",Mathf.Abs(v));
	}
	// Xu ly: quay nguoc hinh khi di nguoc
	void ChangeDirectionAnimation(float h)
	{
		if(h > 0 && !isChangeDirection || h < 0 && isChangeDirection){
		isChangeDirection = !isChangeDirection;
		Vector3 scale = transform.localScale;
		scale.x *= -1;
		transform.localScale = scale;
		}
	}

}
