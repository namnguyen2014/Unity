﻿using UnityEngine;
using System.Collections;

public class JackMovement : MonoBehaviour {

	private float timeofMove = 3.5f;
	private float speedofJack = 1.5f;
	private float Jack_MaxHP = 10;
	private float Jack_CurrentHP;

	private Transform NinjaTrans;
	private Animator JackAnimator;
	//private Rigidbody2D rb2D;

	private void Start()
	{
		NinjaTrans = GameObject.FindWithTag("Ninja").transform;
		JackAnimator = GetComponent<Animator>();
		//rb2D = GetComponent<Rigidbody2D>();
		Jack_CurrentHP = Jack_MaxHP;
	}

	private void Update()
	{
		JackMove();
	}
	// Update is called once per frame
	private void JackMove () {
		timeofMove -= Time.deltaTime;
		if(timeofMove <= 0)
		{
			speedofJack = -speedofJack;
			Vector3 scale = transform.localScale;
			scale.x *= -1;
			transform.localScale = scale;
			timeofMove = 3.5f;
		}
		gameObject.transform.Translate(new Vector2 (1* speedofJack * Time.deltaTime, 0));
		JackAnimator.SetInteger("State",1);
	}
	private void OnTriggerEnter2D(Collider2D isNinja)
	{
		if(isNinja.gameObject.tag == "Ninja")
		{
			Debug.Log("Touched: " + isNinja.name);
			//gameObject.transform.Translate(new Vector2 (NinjaTrans.position.x * speedofJack, 0));
			//JackAnimator.SetInteger("isRun",1);
		}
	}
}
