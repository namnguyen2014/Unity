﻿using UnityEngine;
using System.Collections;

public class PacmanManagement : MonoBehaviour {

	private Rigidbody2D rb2D;
	private Vector2 vect_Velocity;

	// Use this for initialization
	void Start () {
		rb2D = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		Move ();
	}

	void Move()
	{
		float speed = 10f;
		rb2D.velocity = new Vector2 (0,0);

		if(Input.GetKey(KeyCode.UpArrow))
		{
			rb2D.velocity = new Vector2 (0,1) * speed;
		}	
		else if (Input.GetKey(KeyCode.DownArrow))
		{
			rb2D.velocity = new Vector2 (0,-1) * speed;
		}
		else if (Input.GetKey(KeyCode.LeftArrow))
		{
			rb2D.velocity = new Vector2 (-1,0) * speed;
		}
		else if (Input.GetKey(KeyCode.RightArrow))
		{
			rb2D.velocity = new Vector2 (1,0) * speed;
		}
	}

	private void OnCollisionEnter2D(Collision2D col)
	{
		if(col.gameObject.tag == "Enemy")
		{
			Destroy (gameObject);
		}
	}
}
