﻿using UnityEngine;
using System.Collections;

public class EnemyManagement : MonoBehaviour {

	private Rigidbody2D e_rb2D;
	private float speed = 1f;

	// Use this for initialization
	void Start () {
		e_rb2D = GetComponent<Rigidbody2D> ();
	}
	
	// Update is called once per frame
	void Update () 
	{
		e_rb2D.velocity = new Vector2 (1, 0) * speed;
	}


	private void OnCollisionEnter2D(Collision2D col)
	{
		if(col.gameObject.tag == "Obs")
		{
			speed *= -1;
		}
	}
}