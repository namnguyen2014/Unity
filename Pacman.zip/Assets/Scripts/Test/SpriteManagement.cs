﻿using UnityEngine;
using System.Collections;
using UnityEngine.UI;

public class SpriteManagement : MonoBehaviour
{
	public Sprite img_default;
	public Sprite img_clicked;
	private Image imgButton;
	private GameManager gameMana;

	public void Start ()
	{
		imgButton = GetComponent<Image> ();
		gameMana = FindObjectOfType<GameManager> ();
	}

	public void OnMouseDown ()
	{
		if (gameMana.card_1 == null || gameMana.card_2 == null) {
			TweenSelectedButton ();
			ChangrSprite ();
			gameMana.OnClickManager (gameObject);
		}
	}

	public void ChangrSprite ()
	{
		if (imgButton.sprite == img_default) {
			imgButton.sprite = img_clicked;
		} else {
			imgButton.sprite = img_default;
		}
	}
	void TweenSelectedButton()
	{
		LeanTween.rotateY (gameObject, 180f, 0.5f).setOnComplete(() =>
			{
				gameObject.transform.rotation = Quaternion.identity;
			});
				
	}
}
