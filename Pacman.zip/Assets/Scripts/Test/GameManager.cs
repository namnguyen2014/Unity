﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{

	public GameObject card_1;
	public GameObject card_2;
	private SpriteManagement spriteMana;
	public GameObject replayOption;
	public Text txtScore;
	public int score = 0;
	public Text txtTime;
	public Text yourPoint;
	public float timeCouting = 0;
	private float second = 1;
	private int countToVictory = 0;

	public void Start (){
		spriteMana = FindObjectOfType<SpriteManagement>();
	}
		
	public void Update()
	{
		CountOneSecond ();
	}

	public void OnClickManager (GameObject cardCheck)
	{
		if (card_1 == null) {
			card_1 = cardCheck;
			Debug.Log("card 1 is " + cardCheck.GetComponent<Image>().sprite.name);
		} 
		else if (card_1.GetInstanceID() != cardCheck.GetInstanceID())
		{
			card_2 = cardCheck;
			Debug.Log("card 2 is " + cardCheck.GetComponent<Image>().sprite.name);
		}
		else
		{
			card_1 = null;
		}
			
		if (card_1 != null && card_2 != null)
		{
			if (card_1.GetComponent<Image>().sprite == card_2.GetComponent<Image>().sprite)
			{
				Debug.Log("Matched!");
				Invoke ("DisableImg", 0.5f);
				score += 1;
				SetTextScore ();
				countToVictory += 1;
				EndGame ();
			}
			else
			{
				Invoke("Reset", 1f);
			}
		}
	}

	void Reset()
	{
		card_1.GetComponent<Image>().sprite = card_1.GetComponent<SpriteManagement>().img_default;
		card_2.GetComponent<Image>().sprite = card_2.GetComponent<SpriteManagement>().img_default;
		ResetCard1_2();
	}

	void ResetCard1_2()
	{
		card_1 = null;
		card_2 = null;
	}
	// Trùng nhau là biến mất
	void DisableImg()
	{
		card_1.GetComponent<Image> ().enabled = false;
		card_2.GetComponent<Image> ().enabled = false;
		ResetCard1_2 ();
	}
	// hàm set Scrore
	void SetTextScore()
	{
		txtScore.text = "Score: " + score.ToString ();
	}
	// hàm set Time
	void SetTextTimeCounting()
	{
		txtTime.text = "Time: " + timeCouting.ToString ();
	}
	// hàm đếm 1 second
	void CountOneSecond()
	{
		if (second > 0) 
		{
			second -= Time.deltaTime;
			if (second <= 0) 
			{
				timeCouting++;
				SetTextTimeCounting ();
				second = 1;
			}
		}
	}

	// hàm End Game
	void EndGame()
	{
		if (countToVictory == 8) 
		{
			// ngưng đếm thời gian
			second = 0;
			replayOption.SetActive (true);
			yourPoint.text = "You got " + score.ToString() + " points in " + timeCouting.ToString() + " seconds.";
		}
	}
}