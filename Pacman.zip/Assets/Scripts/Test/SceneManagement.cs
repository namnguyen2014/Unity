﻿using UnityEngine;
using System.Collections;
using UnityEngine.SceneManagement;

public class SceneManagement : MonoBehaviour {

	// Use this for initialization
	public void Start () {
		SceneManager.LoadScene ("PlayGame_Page");	
	}
//
//	public void SceneHome()
//	{
//		SceneManager.LoadScene ("Home_Page");
//	}

//	public void SceneGameCuteMode()
//	{
//		SceneManager.LoadScene ("PlayGame_Play_1");
//	}
}
