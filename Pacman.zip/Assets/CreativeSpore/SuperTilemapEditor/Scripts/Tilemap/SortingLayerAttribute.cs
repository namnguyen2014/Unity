﻿using UnityEngine;
using System.Collections;

namespace CreativeSpore.SuperTilemapEditor 
{
	public class SortingLayerAttribute : PropertyAttribute { }
}