﻿using UnityEngine;
using System.Collections.Generic;
using UnityEngine.UI;

public class InitGameBoard : MonoBehaviour {

	public Transform parentPanel;
	public GameObject btnPrefabs;
	public List<Sprite> lstImg = new List<Sprite>(); // list chua 8 hinh (16 button - 8 cap hinh)
	public GameManager gameMana;
	public GameObject replayOption_Init;

	private List<SpriteManagement> lstBtnCloned = new List<SpriteManagement>(); // lst chua nhung button dc Instance
	private List<int> ImgIndex = new List<int>();

	// Use this for initialization
	public void Start () {
		CreateNewBoard ();
	}

	public void RandomImg()
	{
		// Duplicate hinh: 8 index
		for(int i = 0; i < lstImg.Count; i++)
		{
			ImgIndex.Add(i);
			ImgIndex.Add(i);
		}
		// Add img vao button Clone, r xoa imgIndex do khoi list de ko gap lai
		for(int i = 0; i < lstBtnCloned.Count; i++)
		{
			lstBtnCloned [i].GetComponent<Image> ().enabled = true;
			lstBtnCloned [i].GetComponent<Image> ().sprite = lstBtnCloned [i].img_default;
			int index = Random.Range(0, ImgIndex.Count);
			lstBtnCloned[i].img_clicked = lstImg[ImgIndex[index]];
			ImgIndex.RemoveAt(index);
		}
		replayOption_Init.SetActive (false);
	}

	public int CheckOnlyTwoImg(Sprite spriteCheck) // chi cho hien 2 img (1 cap hinh)
	{
		int count = 0;
		for(int i = 0; i < lstBtnCloned.Count; i++)
		{
			if(spriteCheck == lstBtnCloned[i].img_clicked)
			{
				count++;
			}
			else if(count >= (lstBtnCloned.Count/lstImg.Count))
			{
				return count;
			}
		}
		return count;
	}

	public void CreateNewBoard()
	{
		for(int i = 0 ; i < 16; i++)
		{
			GameObject btnCloned = Instantiate(btnPrefabs);
			btnCloned.transform.SetParent(parentPanel, false);

			lstBtnCloned.Add(btnCloned.GetComponent<SpriteManagement>()); // add button Instanced vao List
		}
		RandomImg();
	}
}
