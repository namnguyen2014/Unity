﻿using UnityEngine;
using System.Collections;

public class GameManager2 : MonoBehaviour {

	public GameObject spawnPoint;
	public Transform enemyPrefab;
	public GameObject target;

	private float positionX;
	private float positionY;
	private float speed = 0.1f;
	// Use this for initialization
	void Start () {
//		positionX = target.transform.position.x;
//		positionY = target.transform.position.y;
	}
	
	// Update is called once per frame
	void Update () {
		if(Input.GetKey(KeyCode.Space))
		{
			CloneEnemy ();
		}
	
	}

	public void CloneEnemy()
	{
		Instantiate (enemyPrefab);
	}
}
