﻿using UnityEngine;
using System.Collections;

public class RightElevatorMovement : MonoBehaviour {
	float REmovingTime = 1.5f;
	float movementSpeed  = 0.06f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		REmovingTime -= Time.deltaTime;
		if(REmovingTime <= 0)
		{
			movementSpeed = - movementSpeed;
			REmovingTime = 1.5f;
		}
		gameObject.transform.Translate(new Vector2(0, 1) * movementSpeed);
	}
}
