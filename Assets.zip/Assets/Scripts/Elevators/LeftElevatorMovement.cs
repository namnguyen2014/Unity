﻿using UnityEngine;
using System.Collections;

public class LeftElevatorMovement : MonoBehaviour {
	float movingTime = 1.2f;
	float movementSpeed  = 0.06f;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		movingTime -= Time.deltaTime;
		if(movingTime <= 0)
		{
			movementSpeed = - movementSpeed;
				movingTime = 1.2f;
		}
		gameObject.transform.Translate(new Vector2(1, 0) * movementSpeed);
	}
}
