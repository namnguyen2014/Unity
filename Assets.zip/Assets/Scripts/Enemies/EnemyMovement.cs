﻿using UnityEngine;
using System.Collections;

public class EnemyMovement : MonoBehaviour {

	float timeofMove = 3.5f;
	float speedofEnemy = 1.5f;

	// Update is called once per frame
	void Update () {
		timeofMove -= Time.deltaTime;
		if(timeofMove <= 0)
		{
			speedofEnemy = -speedofEnemy;
			Vector3 scale = transform.localScale;
			scale.x *= -1;
			transform.localScale = scale;
			timeofMove = 3.5f;
		}
		gameObject.transform.Translate(new Vector2 (1* speedofEnemy * Time.deltaTime, 0));
	}
}
