﻿using UnityEngine;
using System.Collections;

public class ExampleShoot : MonoBehaviour {

		float delayTime = 1;
		public GameObject prefabsKunai;

		// Update is called once per frame
		void Update ()
		{
				shoot();
		}
		void shoot()
		{
		Transform shotBullet = Instantiate(prefabsKunai,transform.position, transform.rotation) as Transform;
		}
	}
