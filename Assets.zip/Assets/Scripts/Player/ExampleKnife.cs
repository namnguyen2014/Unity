﻿using UnityEngine;
using System.Collections;

public class ExampleKnife : MonoBehaviour {
	private float speed = 5;
	
	// Update is called once per frame
	void Update () {
		gameObject.transform.Translate (Vector2.right * speed * Time.deltaTime);
	}
}
