﻿using UnityEngine;
using System.Collections.Generic;

public class TweenImg : MonoBehaviour {


	public List<GameObject> listImg = new List<GameObject>();
	public List<GameObject> listBox = new List<GameObject>();
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
}
