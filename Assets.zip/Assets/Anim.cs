﻿using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;

public class Anim : MonoBehaviour {

	public List<GameObject> listImg = new List<GameObject>();
	public List<GameObject> listBox = new List<GameObject>();

	public void tweenImgToBox()
	{
		for(int i = 0; i < listImg.Count; i++)
		{
			LeanTween.moveLocal(listImg[i], listBox[i].transform.position, 0.25f);
		}
	}
}
